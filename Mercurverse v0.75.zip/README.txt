Please make sure you have the pehkui mod installed.
(v2.20 as of this version of Mercurverse)
Also make sure you have the resource pack installed.
(Oni's custom weapon will appear as an iron axe if not correctly installed)

<3 Mercury
